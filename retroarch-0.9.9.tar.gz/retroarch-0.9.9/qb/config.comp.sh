USE_LANG_C="yes"
USE_LANG_CXX="yes"
