#ifndef __RL_FNMATCH_H__
#define __RL_FNMATCH_H__

#define	FNM_NOMATCH	1

int rl_fnmatch(const char *pattern, const char *string, int flags);

#endif
