#ifndef _RGL_EXPORT_DEFINE_H
#define _RGL_EXPORT_DEFINE_H

#define PSGL_EXPORT
#define RGL_EXPORT

#endif
